﻿학생용 학교생활 관리 앱 - EXE 제작 키트

중요:
- 이 키트는 학생용 앱만 포함합니다. 선생님용 앱은 포함하지 않습니다.
- 현재 전달 환경은 Linux이므로 Windows용 .exe 바이너리를 여기서 직접 빌드할 수 없습니다.
- 대신 Windows에서 한 번 실행하면 .exe를 만드는 배치 파일을 포함했습니다.
- 최종 .exe를 만드는 컴퓨터에는 제작 시 Python 3.11 또는 3.12가 필요합니다.
- 완성된 앱을 실행하는 컴퓨터에는 Python을 따로 설치할 필요가 없습니다.

만드는 방법:
1. ZIP 파일 전체를 Windows 컴퓨터에 압축 해제합니다.
2. 인터넷에 연결한 상태에서 EXE_만들기.bat을 더블 클릭합니다.
3. 필요한 빌드 도구를 자동 설치하고 EXE를 생성합니다.
4. 완성 파일은 dist\SchoolLifeManager\SchoolLifeManager.exe 입니다.
5. 다른 컴퓨터로 옮길 때는 EXE 파일 하나만 옮기지 말고
   dist\SchoolLifeManager 폴더 전체를 옮겨야 합니다.

포함 기능:
- 시간표 관리 및 저장
- 수행평가 달력 및 일정 관리
- 이미지 OCR (Pillow / pytesseract)
- 선생님 호출 알림 확인
- Firebase 연동

주의:
- OCR을 사용하려면 실행 컴퓨터에도 Tesseract OCR 프로그램이 별도로 설치되어 있어야 합니다.
- Tesseract가 없어도 시간표, 수행평가 등 나머지 기능은 사용할 수 있습니다.
- Firebase 연결은 firebase_config.json의 프로젝트 설정 및 Firebase 보안 규칙에 따라 달라집니다.
- database.rules.json은 참고/배포용 규칙 파일이며, 실제 Firebase 콘솔에 적용해야 서버 권한이 설정됩니다.
- 첫 빌드에는 인터넷 연결이 필요합니다.
