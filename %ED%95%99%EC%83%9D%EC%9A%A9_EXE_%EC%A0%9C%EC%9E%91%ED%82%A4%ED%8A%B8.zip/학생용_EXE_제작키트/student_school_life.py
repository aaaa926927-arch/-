"""
학생용 학교생활 관리 앱
- 시간표: 각 칸을 클릭해 수업 입력/수정
- 선생님 호출: 추가 및 항목별 관리
- 수행평가: 달력에서 날짜를 클릭해 일정 관리
- 파일 OCR: 이미지 파일을 선택해 글자를 읽고 핵심 정보를 정리
- 선생님 호출: 이메일 초안 보내기 및 답장 기록\n- 자동 저장: 시간표, 메시지, 수행평가, 사용자 정보는 앱을 닫아도 유지

실행 안내:
    기본 화면(시간표/선생님 호출/수행평가 달력)은 tkinter만으로 실행됩니다.
    이미지 OCR 기능(Python 3.15): py -m pip install --upgrade pillow pytesseract
    카메라 기능은 사용하지 않고 이미지 파일을 직접 선택합니다.

추가 설치:
    OCR을 사용하려면 Tesseract OCR 프로그램도 별도로 설치해야 합니다.
"""

import calendar
import json
import re
import webbrowser
from urllib.parse import quote, quote_plus
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from datetime import date, datetime
from pathlib import Path

# 선택 기능: 이미지 처리. Pillow가 없어도 기본 화면은 실행되도록 합니다.
try:
    from PIL import Image, ImageTk
except ImportError:
    Image = None
    ImageTk = None

# 선택 기능: OCR
try:
    import pytesseract
except ImportError:
    pytesseract = None

# Windows의 일반적인 설치 위치를 자동으로 확인합니다.
# Tesseract 프로그램은 pip 라이브러리와 별도로 설치해야 합니다.
def configure_tesseract():
    if pytesseract is None:
        return
    import shutil
    candidates = [
        shutil.which("tesseract"),
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            pytesseract.pytesseract.tesseract_cmd = str(candidate)
            return

configure_tesseract()


BG = "#F4F6FA"
WHITE = "#FFFFFF"
NAVY = "#273858"
BLUE = "#5278E8"
LIGHT_BLUE = "#E9EFFF"
GREEN = "#35A879"
LIGHT_GREEN = "#E3F6ED"
ORANGE = "#F09A43"
LIGHT_ORANGE = "#FFF0DF"
GRAY = "#DCE2EC"
TEXT = "#263247"
RED = "#D9534F"

FONT = ("Malgun Gothic", 10)
TITLE_FONT = ("Malgun Gothic", 18, "bold")
SMALL_FONT = ("Malgun Gothic", 9)


# Firebase 통신 기능을 이 파일 안에 포함했습니다.
"""Firebase REST client: anonymous Firebase Auth + Realtime Database."""
import json, urllib.request, urllib.error
from pathlib import Path

BASE = Path(__file__).resolve().parent
CONFIG_FILE = BASE / "firebase_config.json"
try:
    CONFIG = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
except Exception:
    CONFIG = {}
TOKEN_FILE = Path.home() / "SchoolLifeManager" / "firebase_session.json"

class FirebaseClient:
    def __init__(self):
        if not CONFIG.get("api_key") or not CONFIG.get("database_url"):
            raise RuntimeError("firebase_config.json에 Firebase api_key와 database_url을 설정해 주세요.")
        self.api_key = CONFIG["api_key"]
        self.db = CONFIG["database_url"].rstrip("/")
        self.session = self._load_or_sign_in()

    def _request(self, url, method="GET", payload=None):
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode()
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"Content-Type":"application/json"})
        try:
            with urllib.request.urlopen(req, timeout=15) as response:
                raw=response.read().decode()
                return json.loads(raw) if raw else None
        except urllib.error.HTTPError as e:
            detail=e.read().decode(errors="replace")
            raise RuntimeError(f"Firebase 오류 {e.code}: {detail}")

    def _auth(self, endpoint, payload):
        return self._request(f"https://identitytoolkit.googleapis.com/v1/accounts:{endpoint}?key={self.api_key}", "POST", payload)

    def _load_or_sign_in(self):
        TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
        if TOKEN_FILE.exists():
            try:
                saved=json.loads(TOKEN_FILE.read_text(encoding="utf-8"))
                refreshed=self._request(f"https://securetoken.googleapis.com/v1/token?key={self.api_key}", "POST",
                    {"grant_type":"refresh_token","refresh_token":saved["refreshToken"]})
                session={"idToken":refreshed["id_token"],"refreshToken":refreshed["refresh_token"],"localId":saved["localId"]}
                self._save(session); return session
            except Exception:
                pass
        session=self._auth("signUp", {"returnSecureToken":True})
        self._save(session)
        return session

    def _save(self, session):
        TOKEN_FILE.write_text(json.dumps({"idToken":session["idToken"],"refreshToken":session["refreshToken"],"localId":session["localId"]}), encoding="utf-8")
        self.session=session

    @property
    def uid(self): return self.session["localId"]

    def _db(self, path, method="GET", payload=None):
        url=f"{self.db}/{path.strip('/')}.json?auth={self.session['idToken']}"
        try: return self._request(url, method, payload)
        except RuntimeError as e:
            if "401" in str(e):
                refreshed=self._request(f"https://securetoken.googleapis.com/v1/token?key={self.api_key}", "POST",
                    {"grant_type":"refresh_token","refresh_token":self.session["refreshToken"]})
                self._save({"idToken":refreshed["id_token"],"refreshToken":refreshed["refresh_token"],"localId":self.uid})
                url=f"{self.db}/{path.strip('/')}.json?auth={self.session['idToken']}"
                return self._request(url,method,payload)
            raise

    def register_student(self, name, student_id):
        if not name.strip() or not student_id.strip(): raise ValueError("이름과 학번을 입력해야 합니다.")
        self._db(f"students/{self.uid}", "PUT", {"name":name.strip(),"studentId":student_id.strip(),"active":True})

    def get_my_calls(self):
        data=self._db(f"calls/{self.uid}") or {}
        items=[]
        for key,value in data.items():
            if isinstance(value,dict): items.append({"id":key,**value})
        return sorted(items,key=lambda x:x.get("createdAt",""),reverse=True)

    def acknowledge_call(self, call_id):
        self._db(f"calls/{self.uid}/{call_id}/acknowledged", "PUT", True)

    def get_students(self):
        data=self._db("students") or {}
        return [{"uid":uid,**v} for uid,v in data.items() if isinstance(v,dict) and v.get("active",True)]

    def send_call(self, uid, message):
        import datetime
        self._db(f"calls/{uid}", "POST", {"message":message,"createdAt":datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),"acknowledged":False})


class SchoolLifeApp:
    def __init__(self, root):
        self.root = root
        self.root.title("학교생활 관리 프로그램")
        self.root.geometry("1450x850")
        self.root.minsize(1150, 720)
        self.root.configure(bg=BG)

        # 모든 입력 자료는 사용자 홈 폴더에 JSON으로 저장합니다.
        self.data_dir = Path.home() / "SchoolLifeManager"
        self.data_file = self.data_dir / "school_life_data.json"
        saved = self.load_data()

        self.name = saved.get("name") or simpledialog.askstring(
            "사용자 정보", "이름을 입력하세요:", parent=root
        ) or "학생"
        self.student_id = saved.get("student_id") or simpledialog.askstring(
            "사용자 정보", "학번을 입력하세요:", parent=root
        ) or "미입력"

        self.schedule = saved.get("schedule") or [["" for _ in range(5)] for _ in range(7)]
        self.performances = saved.get("performances", {})
        self.teacher_email = saved.get("teacher_email", "")
        self.selected_date = date.today()
        self.calendar_buttons = []
        self.cloud = None
        self.cloud_error = ""
        try:
            self.cloud = FirebaseClient()
            self.cloud.register_student(self.name, self.student_id)
        except Exception as exc:
            self.cloud_error = str(exc)

        self._style()
        self._build_header()
        self._build_main()
        self.refresh_calendar()
        self.refresh_schedule()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.save_data()

    def load_data(self):
        """저장된 자료를 읽습니다. 파일이 없거나 손상되었으면 빈 자료로 시작합니다."""
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            if self.data_file.exists():
                with self.data_file.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError) as exc:
            messagebox.showwarning(
                "저장 파일 확인",
                f"저장된 자료를 읽지 못해 새로 시작합니다.\n{exc}",
                parent=self.root
            )
        return {}

    def save_data(self):
        """시간표, 메시지, 수행평가 및 사용자 설정을 JSON 파일에 저장합니다."""
        try:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            data = {
                "name": self.name,
                "student_id": self.student_id,
                "schedule": self.schedule,
                "performances": self.performances,
                "teacher_email": getattr(self, "teacher_email", "")
            }
            temp_file = self.data_file.with_suffix(".tmp")
            with temp_file.open("w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            temp_file.replace(self.data_file)
        except OSError as exc:
            messagebox.showerror(
                "저장 오류",
                f"자료를 저장하지 못했습니다.\n{exc}",
                parent=self.root
            )

    def on_close(self):
        self.save_data()
        self.root.destroy()

    def ask_profile_again(self):
        """이름과 학번을 한 창에서 다시 입력받습니다."""
        dialog = tk.Toplevel(self.root)
        dialog.title("사용자 정보 입력")
        dialog.configure(bg=BG)
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()

        tk.Label(
            dialog, text="새 사용자 정보를 입력하세요", bg=BG, fg=NAVY,
            font=("Malgun Gothic", 14, "bold")
        ).pack(padx=24, pady=(20, 12))
        form = tk.Frame(dialog, bg=BG)
        form.pack(padx=24, pady=4, fill="x")

        tk.Label(form, text="이름", bg=BG, font=FONT).grid(row=0, column=0, sticky="w", pady=6)
        name_entry = tk.Entry(form, font=FONT, width=24)
        name_entry.grid(row=0, column=1, padx=(12, 0), pady=6)
        tk.Label(form, text="학번", bg=BG, font=FONT).grid(row=1, column=0, sticky="w", pady=6)
        id_entry = tk.Entry(form, font=FONT, width=24)
        id_entry.grid(row=1, column=1, padx=(12, 0), pady=6)

        result = {"profile": None}
        def submit():
            name = name_entry.get().strip()
            student_id = id_entry.get().strip()
            if not name or not student_id:
                messagebox.showwarning("입력 확인", "이름과 학번을 모두 입력해 주세요.", parent=dialog)
                return
            result["profile"] = (name, student_id)
            dialog.destroy()

        buttons = tk.Frame(dialog, bg=BG)
        buttons.pack(pady=(12, 20))
        tk.Button(buttons, text="확인", command=submit, bg=NAVY, fg="white", font=FONT, width=10).pack(side="left", padx=5)
        tk.Button(buttons, text="취소", command=dialog.destroy, font=FONT, width=10).pack(side="left", padx=5)
        dialog.bind("<Return>", lambda _event: submit())
        dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)
        name_entry.focus_set()
        self.root.wait_window(dialog)
        return result["profile"]

    def reset_all_data(self):
        """프로필, 시간표, 메시지, 수행평가 및 이메일 설정을 모두 초기화합니다."""
        confirmed = messagebox.askyesno(
            "전체 초기화 확인",
            "저장된 이름·학번, 시간표, 선생님 호출, 수행평가 일정, 이메일 설정을\n"
            "모두 삭제하고 초기 상태로 되돌릴까요?\n\n이 작업은 되돌릴 수 없습니다.",
            icon="warning", parent=self.root
        )
        if not confirmed:
            return

        profile = self.ask_profile_again()
        if profile is None:
            return

        # 기존 저장 파일을 실제로 삭제한 뒤, 새 프로필만 가진 초기 상태로 다시 저장합니다.
        try:
            if self.data_file.exists():
                self.data_file.unlink()
        except OSError as exc:
            messagebox.showerror(
                "초기화 실패",
                f"저장 파일을 삭제하지 못해 초기화를 진행할 수 없습니다.\n{exc}",
                parent=self.root
            )
            return

        self.name, self.student_id = profile
        self.schedule = [["" for _ in range(5)] for _ in range(7)]
        self.performances = {}
        self.teacher_email = ""
        self.selected_date = date.today()
        if self.cloud is not None:
            try:
                self.cloud.register_student(self.name, self.student_id)
            except Exception as exc:
                messagebox.showwarning("서버 등록", str(exc), parent=self.root)

        if hasattr(self, "teacher_email_var"):
            self.teacher_email_var.set("")
        self.profile_label.configure(text=f"이름: {self.name}    학번: {self.student_id}")
        self.refresh_schedule()
        self.refresh_calendar()
        self.refresh_performance_list()
        self.save_data()
        messagebox.showinfo(
            "초기화 완료",
            "기존 저장 파일과 모든 기록을 삭제했어요.\n새 이름과 학번으로 처음부터 시작합니다.",
            parent=self.root
        )

    def _style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TButton", font=FONT, padding=6)
        style.configure("TCombobox", font=FONT)

    def _build_header(self):
        header = tk.Frame(self.root, bg=NAVY, height=82)
        header.pack(fill="x")
        header.pack_propagate(False)
        tk.Label(
            header, text="학교생활 관리 프로그램", bg=NAVY, fg=WHITE,
            font=("Malgun Gothic", 23, "bold")
        ).pack(side="left", padx=28)
        self.profile_label = tk.Label(
            header, text=f"이름: {self.name}    학번: {self.student_id}",
            bg=NAVY, fg=WHITE, font=("Malgun Gothic", 12)
        )
        self.profile_label.pack(side="right", padx=(8, 20))
        tk.Button(
            header, text="전체 초기화", bg=RED, fg=WHITE,
            activebackground="#B83B38", activeforeground=WHITE,
            font=SMALL_FONT, command=self.reset_all_data
        ).pack(side="right", padx=8, pady=18)

    def _build_main(self):
        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=16, pady=16)

        body.grid_columnconfigure(0, weight=1, uniform="panel")
        body.grid_columnconfigure(1, weight=1, uniform="panel")
        body.grid_columnconfigure(2, weight=1, uniform="panel")
        body.grid_rowconfigure(0, weight=1)

        self.schedule_panel = self._panel(body, "1. 시간표", BLUE)
        self.schedule_panel.grid(row=0, column=0, sticky="nsew", padx=7)

        self.teacher_panel = self._panel(body, "2. 선생님 호출", GREEN)
        self.teacher_panel.grid(row=0, column=1, sticky="nsew", padx=7)

        self.performance_panel = self._panel(body, "3. 수행평가 달력", ORANGE)
        self.performance_panel.grid(row=0, column=2, sticky="nsew", padx=7)

        self._build_schedule_panel()
        self._build_teacher_panel()
        self._build_performance_panel()

    def _panel(self, parent, title, color):
        panel = tk.Frame(parent, bg=WHITE, highlightbackground=GRAY, highlightthickness=1)
        heading = tk.Frame(panel, bg=color, height=48)
        heading.pack(fill="x")
        heading.pack_propagate(False)
        tk.Label(heading, text=title, bg=color, fg=WHITE, font=TITLE_FONT).pack(
            side="left", padx=14, pady=5
        )
        return panel

    def _build_schedule_panel(self):
        p = self.schedule_panel
        tk.Label(p, text="수업 칸을 클릭해 입력하거나 수정하세요.", bg=WHITE, fg=TEXT,
                 font=SMALL_FONT).pack(anchor="w", padx=12, pady=(12, 6))

        grid = tk.Frame(p, bg=WHITE)
        grid.pack(fill="x", padx=10)
        tk.Label(grid, text="교시", bg=LIGHT_BLUE, width=5, relief="solid",
                 bd=1, font=SMALL_FONT).grid(row=0, column=0, sticky="nsew")
        for c, day in enumerate(["월", "화", "수", "목", "금"], start=1):
            tk.Label(grid, text=day, bg=LIGHT_BLUE, relief="solid", bd=1,
                     font=SMALL_FONT).grid(row=0, column=c, sticky="nsew")
            grid.grid_columnconfigure(c, weight=1, uniform="day")

        self.schedule_cells = []
        for r in range(7):
            tk.Label(grid, text=str(r + 1), bg="#F8FAFD", width=5, relief="solid",
                     bd=1, font=SMALL_FONT).grid(row=r + 1, column=0, sticky="nsew")
            row_cells = []
            for c in range(5):
                btn = tk.Button(
                    grid, text="＋", bg=WHITE, fg=TEXT, activebackground=LIGHT_BLUE,
                    relief="solid", bd=1, wraplength=72, font=("Malgun Gothic", 8),
                    command=lambda rr=r, cc=c: self.edit_class(rr, cc)
                )
                btn.grid(row=r + 1, column=c + 1, sticky="nsew", ipadx=2, ipady=13)
                row_cells.append(btn)
            self.schedule_cells.append(row_cells)

        tk.Button(p, text="시간표 전체 초기화", bg=BLUE, fg=WHITE, font=FONT,
                  command=self.clear_schedule).pack(pady=14)

    def _build_teacher_panel(self):
        p = self.teacher_panel
        tk.Label(p, text="선생님이 내 이름과 학번을 찾아 호출하면 알림이 도착합니다.",
                 bg=WHITE, fg=TEXT, font=SMALL_FONT, wraplength=340,
                 justify="left").pack(anchor="w", padx=12, pady=(12, 8))
        self.call_status = tk.Label(p, text="서버 연결 확인 중...", bg=WHITE,
                                    fg=TEXT, font=SMALL_FONT, wraplength=340)
        self.call_status.pack(anchor="w", padx=12, pady=4)
        self.call_list = tk.Listbox(p, font=FONT, bg=LIGHT_GREEN, fg=TEXT,
                                    relief="flat", selectbackground=GREEN,
                                    activestyle="none")
        self.call_list.pack(fill="both", expand=True, padx=12, pady=8)
        tk.Button(p, text="선택한 호출 확인", bg=GREEN, fg=WHITE,
                  font=FONT, command=self.acknowledge_call).pack(fill="x", padx=12, pady=4)
        tk.Button(p, text="호출 새로고침", font=SMALL_FONT,
                  command=self.poll_calls).pack(fill="x", padx=12, pady=(0, 8))
        if self.cloud_error:
            self.call_status.configure(text="서버 연결 실패: " + self.cloud_error[:180], fg=RED)
        else:
            self.call_status.configure(text="서버 연결 완료 · 호출 알림을 확인합니다.", fg=GREEN)
        self._call_items = []
        self.root.after(2500, self.poll_calls)

    def poll_calls(self):
        if self.cloud is None:
            return
        try:
            items = self.cloud.get_my_calls()
            self._call_items = items
            self.call_list.delete(0, tk.END)
            for item in items:
                status = "확인 완료" if item.get("acknowledged") else "새 호출"
                self.call_list.insert(tk.END, f"[{status}] {item.get('message','선생님이 호출했습니다.')} · {item.get('createdAt','')}")
            if hasattr(self, "call_status"):
                self.call_status.configure(text=f"서버 연결 완료 · 호출 {len(items)}건", fg=GREEN)
        except Exception as exc:
            if hasattr(self, "call_status"):
                self.call_status.configure(text=f"서버 확인 실패: {exc}", fg=RED)
        self.root.after(10000, self.poll_calls)

    def acknowledge_call(self):
        selection = self.call_list.curselection()
        if not selection:
            messagebox.showinfo("안내", "확인할 호출을 선택해 주세요.", parent=self.root)
            return
        item = self._call_items[selection[0]]
        try:
            self.cloud.acknowledge_call(item["id"])
            messagebox.showinfo("확인 완료", "선생님 호출을 확인했어요.", parent=self.root)
            self.poll_calls()
        except Exception as exc:
            messagebox.showerror("전송 실패", str(exc), parent=self.root)

    def _build_performance_panel(self):
        p = self.performance_panel
        tk.Label(p, text="날짜를 누르면 그날의 수행평가를 관리할 수 있어요.",
                 bg=WHITE, fg=TEXT, font=SMALL_FONT, wraplength=360,
                 justify="left").pack(anchor="w", padx=12, pady=(12, 6))

        nav = tk.Frame(p, bg=WHITE)
        nav.pack(fill="x", padx=10)
        tk.Button(nav, text="◀", width=3, command=lambda: self.change_month(-1)).pack(side="left")
        self.month_label = tk.Label(nav, text="", bg=WHITE, fg=TEXT,
                                    font=("Malgun Gothic", 13, "bold"))
        self.month_label.pack(side="left", expand=True)
        tk.Button(nav, text="▶", width=3, command=lambda: self.change_month(1)).pack(side="right")

        self.calendar_frame = tk.Frame(p, bg=WHITE)
        self.calendar_frame.pack(fill="x", padx=10, pady=6)

        self.day_detail_title = tk.Label(
            p, text="", bg=WHITE, fg=NAVY, font=("Malgun Gothic", 11, "bold")
        )
        self.day_detail_title.pack(anchor="w", padx=12, pady=(4, 2))

        self.performance_list = tk.Listbox(
            p, height=5, font=SMALL_FONT, bg=LIGHT_ORANGE, fg=TEXT,
            relief="flat", selectbackground=ORANGE, activestyle="none"
        )
        self.performance_list.pack(fill="both", expand=True, padx=12, pady=5)
        self.performance_list.bind("<Double-Button-1>", self.edit_selected_performance)

        actions = tk.Frame(p, bg=WHITE)
        actions.pack(fill="x", padx=10, pady=(4, 4))
        tk.Button(actions, text="+ 일정 추가", bg=ORANGE, fg=WHITE,
                  command=self.add_performance).pack(side="left", padx=2)
        tk.Button(actions, text="선택 일정 수정", command=self.edit_selected_performance).pack(
            side="left", padx=2
        )
        tk.Button(actions, text="선택 일정 삭제", command=self.delete_performance).pack(
            side="left", padx=2
        )

        file_area = tk.Frame(p, bg=WHITE)
        file_area.pack(fill="x", padx=10, pady=(4, 10))
        tk.Label(file_area, text="📁", font=("Segoe UI Emoji", 22), bg=WHITE).pack(side="left", padx=5)
        tk.Button(
            file_area, text="파일 선택 및 OCR", bg=NAVY, fg=WHITE,
            command=self.choose_image
        ).pack(side="left", fill="x", expand=True, padx=4)
        tk.Label(file_area, text="이미지 파일에서 날짜·과목·내용 추출", bg=WHITE,
                 fg="#68758A", font=("Malgun Gothic", 8), wraplength=120).pack(side="left", padx=4)

    # ---------- 시간표 ----------
    def refresh_schedule(self):
        for r in range(7):
            for c in range(5):
                value = self.schedule[r][c]
                self.schedule_cells[r][c].configure(
                    text=value if value else "＋",
                    bg=LIGHT_BLUE if value else WHITE
                )

    def edit_class(self, row, col):
        days = ["월", "화", "수", "목", "금"]
        value = simpledialog.askstring(
            f"{days[col]}요일 {row + 1}교시",
            "수업 이름을 입력하세요.\n비워 두면 수업이 삭제됩니다.",
            initialvalue=self.schedule[row][col],
            parent=self.root
        )
        if value is not None:
            self.schedule[row][col] = value.strip()
            self.save_data()
            self.refresh_schedule()

    def clear_schedule(self):
        if messagebox.askyesno("시간표 초기화", "시간표를 모두 지울까요?", parent=self.root):
            self.schedule = [["" for _ in range(5)] for _ in range(7)]
            self.save_data()
            self.refresh_schedule()

    # ---------- 수행평가 달력 ----------
    def change_month(self, delta):
        year = self.selected_date.year
        month = self.selected_date.month + delta
        if month < 1:
            year -= 1
            month = 12
        elif month > 12:
            year += 1
            month = 1
        self.selected_date = self.selected_date.replace(year=year, month=month, day=1)
        self.refresh_calendar()

    def refresh_calendar(self):
        for child in self.calendar_frame.winfo_children():
            child.destroy()
        self.calendar_buttons.clear()

        year, month = self.selected_date.year, self.selected_date.month
        self.month_label.configure(text=f"{year}년 {month}월")
        weekdays = ["월", "화", "수", "목", "금", "토", "일"]
        for c, day_name in enumerate(weekdays):
            color = RED if c == 6 else (BLUE if c == 5 else TEXT)
            tk.Label(self.calendar_frame, text=day_name, bg=WHITE, fg=color,
                     font=SMALL_FONT, width=4).grid(row=0, column=c, padx=1, pady=2)

        cal = calendar.Calendar(firstweekday=0)
        for r, week in enumerate(cal.monthdayscalendar(year, month), start=1):
            for c, day in enumerate(week):
                if day == 0:
                    tk.Label(self.calendar_frame, text="", bg=WHITE, width=4,
                             height=2).grid(row=r, column=c, padx=1, pady=1)
                    continue
                key = date(year, month, day).isoformat()
                has_event = bool(self.performances.get(key))
                is_selected = date(year, month, day) == self.selected_date
                bg = ORANGE if is_selected else (LIGHT_ORANGE if has_event else "#F8FAFD")
                fg = WHITE if is_selected else (RED if c == 6 else (BLUE if c == 5 else TEXT))
                label = f"{day}\n•" if has_event else str(day)
                btn = tk.Button(
                    self.calendar_frame, text=label, width=4, height=2,
                    bg=bg, fg=fg, relief="flat", font=SMALL_FONT,
                    command=lambda d=day: self.select_calendar_day(d)
                )
                btn.grid(row=r, column=c, padx=1, pady=1, sticky="nsew")
                self.calendar_buttons.append(btn)

        self.refresh_performance_list()

    def select_calendar_day(self, day):
        self.selected_date = self.selected_date.replace(day=day)
        self.refresh_calendar()

    def selected_key(self):
        return self.selected_date.isoformat()

    def refresh_performance_list(self):
        key = self.selected_key()
        self.day_detail_title.configure(text=f"{self.selected_date:%Y년 %m월 %d일} 수행평가")
        self.performance_list.delete(0, tk.END)
        items = self.performances.get(key, [])
        for item in items:
            self.performance_list.insert(tk.END, f"{item['subject']} — {item['content'].splitlines()[0][:55]} (제출: {item['due'] or '미정'})")
        if not items:
            self.performance_list.insert(tk.END, "일정이 없습니다. '+ 일정 추가'를 눌러 기록하세요.")

    def add_performance(self, initial=None):
        self.open_performance_editor(initial=initial or {}, title="수행평가 추가")

    def open_performance_editor(self, initial=None, title="수행평가 수정", edit_index=None):
        """내용 입력은 여러 줄 자동 줄바꿈을 지원합니다."""
        initial = initial or {}
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("520x440")
        win.minsize(420, 360)
        win.configure(bg=BG)
        win.transient(self.root)
        win.grab_set()
        existing = None
        if edit_index is not None:
            existing = self.performances.get(self.selected_key(), [])[edit_index]
        subject_var = tk.StringVar(value=(existing or initial).get("subject", ""))
        due_var = tk.StringVar(value=(existing or initial).get("due", self.selected_date.strftime("%Y-%m-%d")))
        tk.Label(win, text="과목", bg=BG, fg=TEXT, font=FONT).pack(anchor="w", padx=14, pady=(12, 2))
        subject_entry = tk.Entry(win, textvariable=subject_var, font=FONT)
        subject_entry.pack(fill="x", padx=14)
        tk.Label(win, text="제출일 / 평가일", bg=BG, fg=TEXT, font=FONT).pack(anchor="w", padx=14, pady=(8, 2))
        due_entry = tk.Entry(win, textvariable=due_var, font=FONT)
        due_entry.pack(fill="x", padx=14)
        tk.Label(win, text="중요 정보 / 수행평가 내용 (글이 끝에 닿으면 자동으로 다음 줄로 넘어갑니다)",
                 bg=BG, fg=TEXT, font=FONT).pack(anchor="w", padx=14, pady=(8, 2))
        content_box = tk.Text(win, height=10, wrap="word", font=FONT, bg=WHITE, undo=True)
        content_box.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        content_box.insert("1.0", (existing or initial).get("content", ""))
        bottom = tk.Frame(win, bg=BG)
        bottom.pack(fill="x", padx=14, pady=(0, 12))
        def save_item():
            subject = subject_var.get().strip()
            content = content_box.get("1.0", "end-1c").strip()
            due = due_var.get().strip()
            if not subject:
                messagebox.showwarning("과목 입력", "과목을 입력해 주세요.", parent=win)
                subject_entry.focus_set(); return
            if not content:
                messagebox.showwarning("내용 입력", "중요 정보나 수행평가 내용을 입력해 주세요.", parent=win)
                content_box.focus_set(); return
            item = {"subject": subject, "content": content, "due": due}
            if edit_index is None:
                self.performances.setdefault(self.selected_key(), []).append(item)
            else:
                self.performances[self.selected_key()][edit_index] = item
            self.save_data()
            self.refresh_calendar()
            win.destroy()
        tk.Button(bottom, text="저장", bg=ORANGE, fg=WHITE, font=FONT, command=save_item).pack(side="right", padx=4)
        tk.Button(bottom, text="취소", font=FONT, command=win.destroy).pack(side="right", padx=4)
        subject_entry.focus_set()

    def selected_performance_index(self):
        selection = self.performance_list.curselection()
        if not selection:
            return None
        items = self.performances.get(self.selected_key(), [])
        if selection[0] >= len(items):
            return None
        return selection[0]

    def edit_selected_performance(self, _event=None):
        idx = self.selected_performance_index()
        if idx is None:
            messagebox.showinfo("안내", "수정할 수행평가를 선택하세요.", parent=self.root)
            return
        self.open_performance_editor(title="수행평가 수정", edit_index=idx)

    def delete_performance(self):
        idx = self.selected_performance_index()
        if idx is None:
            messagebox.showinfo("안내", "삭제할 수행평가를 선택하세요.", parent=self.root)
            return
        if messagebox.askyesno("일정 삭제", "선택한 수행평가를 삭제할까요?", parent=self.root):
            key = self.selected_key()
            del self.performances[key][idx]
            if not self.performances[key]:
                del self.performances[key]
            self.save_data()
            self.refresh_calendar()

    # ---------- 파일 선택 / 이미지 OCR ----------
    def choose_image(self):
        """버튼을 누르면 확인창 없이 바로 파일 선택 창을 엽니다."""
        if Image is None:
            messagebox.showerror(
                "Pillow 설치 필요",
                "이미지를 열려면 명령 프롬프트(cmd)에서 다음을 실행하세요:\n"
                "py -m pip install pillow",
                parent=self.root
            )
            return
        path = filedialog.askopenfilename(
            parent=self.root,
            title="수행평가지 이미지 파일 선택",
            filetypes=[
                ("이미지 파일", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp"),
                ("모든 파일", "*.*")
            ]
        )
        if path:
            self.process_image(path)

    def process_image(self, path):
        if Image is None:
            messagebox.showerror(
                "Pillow 필요", "사진 파일을 열려면 명령 프롬프트에서 다음을 실행하세요:\n"
                "py -m pip install pillow", parent=self.root
            )
            return
        if pytesseract is None:
            messagebox.showerror(
                "OCR 라이브러리 필요",
                "OCR 기능을 사용하려면 터미널에서 다음을 실행하세요:\npip install pytesseract pillow\n\n"
                "그리고 Tesseract OCR 프로그램도 별도로 설치해야 합니다.",
                parent=self.root
            )
            return
        try:
            image = Image.open(path)
            # 먼저 한국어+영어를 시도하고, 한국어 데이터가 없으면 영어만 시도합니다.
            # Tesseract 실행 파일 자체가 없으면 설치 안내를 보여줍니다.
            try:
                pytesseract.get_tesseract_version()
            except Exception as exc:
                messagebox.showerror(
                    "Tesseract OCR 설치 필요",
                    "Python 라이브러리는 있지만 Tesseract OCR 프로그램을 찾을 수 없습니다.\n\n"
                    "1) Windows용 Tesseract를 설치하세요: https://github.com/UB-Mannheim/tesseract/wiki\n"
                    "2) 설치할 때 Korean(한국어) 언어 데이터를 선택하세요.\n"
                    "3) 기본 설치 경로(C:\\Program Files\\Tesseract-OCR)를 사용하면 자동으로 찾습니다.\n"
                    "4) 이 프로그램을 닫았다가 다시 실행하세요.\n\n"
                    f"상세 오류: {exc}", parent=self.root
                )
                return
            try:
                extracted = pytesseract.image_to_string(image, lang="kor+eng")
            except Exception:
                try:
                    extracted = pytesseract.image_to_string(image, lang="eng")
                except Exception as exc:
                    messagebox.showerror(
                        "OCR 오류",
                        "사진을 읽지 못했습니다. Tesseract 설치와 언어 데이터를 확인하세요.\n\n"
                        "한국어 인식을 위해 Tesseract의 kor 언어 데이터가 필요합니다.\n\n"
                        f"상세 오류: {exc}", parent=self.root
                    )
                    return
        except Exception as exc:
            messagebox.showerror("이미지 오류", f"이미지 파일을 열지 못했습니다.\n{exc}", parent=self.root)
            return

        summary = self.summarize_ocr(extracted)
        self.show_ocr_result(path, extracted, summary)

    def summarize_ocr(self, text):
        cleaned = [re.sub(r"\s+", " ", line).strip() for line in text.splitlines()]
        lines = [line for line in cleaned if line]
        joined = "\n".join(lines)

        # 날짜 후보: YYYY-MM-DD, YYYY.MM.DD, YYYY/MM/DD, M월 D일, M/D
        date_pattern = r"(?:20\d{2}\s*[./-]\s*\d{1,2}\s*[./-]\s*\d{1,2}|\d{1,2}\s*월\s*\d{1,2}\s*일|\d{1,2}\s*/\s*\d{1,2})"
        dates = list(dict.fromkeys(re.findall(date_pattern, joined)))

        subject = ""
        for line in lines:
            match = re.search(r"(?:과목|교과)\s*[:：]\s*(.+)", line)
            if match:
                subject = match.group(1)[:80]
                break

        keywords = ["제출", "마감", "기한", "준비물", "평가", "주제", "발표", "보고서", "시험", "범위", "점수", "배점"]
        important = []
        for line in lines:
            if any(word in line for word in keywords) and line not in important:
                important.append(line)

        if not important:
            important = lines[:8]

        parts = []
        parts.append(f"과목 추정: {subject or '직접 확인 필요'}")
        parts.append(f"날짜 후보: {', '.join(dates) if dates else '인식된 날짜 없음 — 사진에서 직접 확인하세요.'}")
        parts.append("중요 내용 후보:")
        parts.extend(f"• {line}" for line in important[:10])
        parts.append("")
        parts.append("※ OCR 결과는 오인식할 수 있으므로 원본 평가지와 반드시 대조하세요.")
        return "\n".join(parts)

    def show_ocr_result(self, path, extracted, summary):
        """OCR 결과와 일정 입력칸을 한 화면에 표시합니다."""
        win = tk.Toplevel(self.root)
        win.title("OCR 중요 정보 확인 및 일정 입력")
        win.geometry("900x760")
        win.minsize(760, 620)
        win.configure(bg=BG)
        win.transient(self.root)

        tk.Label(
            win, text="수행평가지 OCR 결과 확인", bg=BG, fg=NAVY,
            font=("Malgun Gothic", 16, "bold")
        ).pack(anchor="w", padx=14, pady=(12, 4))
        tk.Label(
            win, text=f"파일: {Path(path).name}  |  아래 항목을 확인·수정한 뒤 한 번에 저장하세요.",
            bg=BG, fg=TEXT, font=SMALL_FONT, wraplength=850, justify="left"
        ).pack(anchor="w", padx=14, pady=(0, 8))

        form = tk.Frame(win, bg=WHITE, highlightbackground=GRAY, highlightthickness=1)
        form.pack(fill="x", padx=14, pady=4)

        tk.Label(form, text="과목", bg=WHITE, fg=TEXT, font=FONT).grid(
            row=0, column=0, sticky="w", padx=10, pady=(10, 4)
        )
        subject_var = tk.StringVar(value=self.guess_subject(extracted))
        subject_entry = tk.Entry(form, textvariable=subject_var, font=FONT)
        subject_entry.grid(row=0, column=1, sticky="ew", padx=10, pady=(10, 4))

        tk.Label(form, text="제출일 / 평가일", bg=WHITE, fg=TEXT, font=FONT).grid(
            row=1, column=0, sticky="w", padx=10, pady=4
        )
        due_var = tk.StringVar(
            value=self.guess_first_date(extracted) or self.selected_date.strftime("%Y-%m-%d")
        )
        due_entry = tk.Entry(form, textvariable=due_var, font=FONT)
        due_entry.grid(row=1, column=1, sticky="ew", padx=10, pady=4)

        tk.Label(form, text="중요 정보 / 준비물 / 수행평가 내용", bg=WHITE, fg=TEXT,
                 font=FONT).grid(row=2, column=0, sticky="nw", padx=10, pady=4)
        content_box = tk.Text(form, height=6, wrap="word", font=FONT, bg="#FFFDF8")
        content_box.grid(row=2, column=1, sticky="nsew", padx=10, pady=4)
        content_box.insert("1.0", self.short_summary(extracted))
        form.grid_columnconfigure(1, weight=1)

        tk.Label(win, text="인식된 원문 (필요하면 확인하거나 복사하세요)",
                 bg=BG, fg=TEXT, font=("Malgun Gothic", 10, "bold")).pack(
            anchor="w", padx=14, pady=(8, 2)
        )
        raw_frame = tk.Frame(win, bg=BG)
        raw_frame.pack(fill="both", expand=True, padx=14, pady=(0, 6))
        raw_scroll = tk.Scrollbar(raw_frame)
        raw_scroll.pack(side="right", fill="y")
        raw_box = tk.Text(raw_frame, height=8, wrap="word", font=SMALL_FONT,
                          bg=WHITE, yscrollcommand=raw_scroll.set)
        raw_box.pack(side="left", fill="both", expand=True)
        raw_scroll.configure(command=raw_box.yview)
        raw_box.insert("1.0", extracted or "(인식된 글자가 없습니다.)")

        tk.Label(
            win, text="※ OCR은 글자를 잘못 읽을 수 있으니 원본 사진과 대조해 주세요.",
            bg=BG, fg="#68758A", font=SMALL_FONT
        ).pack(anchor="w", padx=14, pady=(0, 4))

        bottom = tk.Frame(win, bg=BG)
        bottom.pack(fill="x", padx=14, pady=(4, 12))

        def save_ocr_performance():
            subject = subject_var.get().strip()
            content = content_box.get("1.0", "end-1c").strip()
            due = due_var.get().strip()
            if not subject:
                messagebox.showwarning("과목 입력", "과목을 입력해 주세요.", parent=win)
                subject_entry.focus_set()
                return
            if not content:
                messagebox.showwarning("중요 정보 입력", "수행평가의 중요 정보를 입력해 주세요.", parent=win)
                content_box.focus_set()
                return
            self.performances.setdefault(self.selected_key(), []).append({
                "subject": subject,
                "content": content,
                "due": due
            })
            self.save_data()
            self.refresh_calendar()
            win.destroy()
            messagebox.showinfo(
                "저장 완료",
                f"{self.selected_date:%Y년 %m월 %d일} 수행평가 일정에 저장했어요.",
                parent=self.root
            )

        tk.Button(
            bottom, text="중요 정보 한 번에 저장", bg=ORANGE, fg=WHITE,
            font=FONT, command=save_ocr_performance
        ).pack(side="left")
        tk.Button(bottom, text="닫기", font=FONT, command=win.destroy).pack(side="right")
        subject_entry.focus_set()

    def guess_subject(self, text):
        for line in text.splitlines():
            match = re.search(r"(?:과목|교과)\s*[:：]\s*(.+)", line.strip())
            if match:
                return match.group(1).strip()[:60]
        return ""

    def guess_first_date(self, text):
        pattern = r"(20\d{2}\s*[./-]\s*\d{1,2}\s*[./-]\s*\d{1,2}|\d{1,2}\s*월\s*\d{1,2}\s*일|\d{1,2}\s*/\s*\d{1,2})"
        match = re.search(pattern, text)
        return match.group(0).strip() if match else ""

    def short_summary(self, text):
        lines = [re.sub(r"\s+", " ", line).strip() for line in text.splitlines() if line.strip()]
        keywords = ["제출", "마감", "기한", "준비물", "평가", "주제", "발표", "보고서", "범위"]
        chosen = [line for line in lines if any(k in line for k in keywords)]
        if not chosen:
            chosen = lines[:5]
        return " / ".join(chosen[:6])[:500] or "OCR 내용을 직접 확인하세요."


if __name__ == "__main__":
    root = tk.Tk()
    app = SchoolLifeApp(root)
    root.mainloop()
