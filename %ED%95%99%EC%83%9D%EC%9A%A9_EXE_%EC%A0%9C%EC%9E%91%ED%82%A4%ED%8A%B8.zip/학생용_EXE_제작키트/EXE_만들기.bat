﻿@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ==========================================
echo   학생용 학교생활 관리 앱 - EXE 제작
echo ==========================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo [오류] EXE 제작용 Python이 필요합니다.
  echo Python 3.11 또는 3.12를 설치하고 다시 실행해 주세요.
  echo 설치할 때 Tcl/Tk 옵션도 선택해 주세요.
  pause
  exit /b 1
)

echo [1/4] 필요한 제작 도구 설치 중...
py -m pip install --upgrade pip
if errorlevel 1 goto fail
py -m pip install pyinstaller pillow pytesseract
if errorlevel 1 goto fail

echo.
echo [2/4] 이전 빌드 파일 정리 중...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist SchoolLifeManager.spec del /q SchoolLifeManager.spec

echo.
echo [3/4] Windows 실행 파일 생성 중...
py -m PyInstaller --noconfirm --clean --windowed --onedir --name SchoolLifeManager --add-data "firebase_config.json;." student_school_life.py
if errorlevel 1 goto fail

echo.
echo [4/4] Firebase 설정 파일 복사 중...
copy /y firebase_config.json "dist\SchoolLifeManager\firebase_config.json" >nul
copy /y database.rules.json "dist\SchoolLifeManager\database.rules.json" >nul

echo.
echo ==========================================
echo 제작 완료!
echo 실행 파일: dist\SchoolLifeManager\SchoolLifeManager.exe
echo ==========================================
echo EXE와 설정 파일이 들어 있는 dist\SchoolLifeManager 폴더 전체를 함께 보관하세요.
pause
exit /b 0

:fail
echo.
echo [오류] 제작에 실패했습니다. 위 오류 내용을 확인해 주세요.
pause
exit /b 1
